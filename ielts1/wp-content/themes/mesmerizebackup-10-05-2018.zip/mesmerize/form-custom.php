<script type="text/javascript">var submitted=false;</script>
    <iframe name="hidden_iframe" id="hidden_iframe" style="display:none;"     
onload="if(submitted) {window.location='http://ielts.ocean.edu.vn/thank-you-page/';}"></iframe>
      <form action="https://docs.google.com/forms/d/e/1FAIpQLSdlp9TGqq1z2mt4zKCmwlz8IPYsF5gjlzwE2x9icm861UDIkA/formResponse" method="post" target="hidden_iframe" 
onsubmit="submitted=true;">

<h3 class = "formh3">Đăng ký kiểm tra trình độ đầu vào</h3>
<div class="ss-form-question errorbox-good" role="listitem">
<div dir="auto" class="ss-item ss-item-required ss-text"><div class="ss-form-entry">
<label class="ss-q-item-label" for="entry_523378717"><div class="ss-q-title"><!-- Họ và tên -->
<label for="itemView.getDomIdToLabel()" aria-label="(Required field)"></label>
<span class="ss-required-asterisk" aria-hidden="true"></span></div>
<div class="ss-q-help ss-secondary-text" dir="auto"></div></label>

<input type="text" name="entry.523378717" value="" class="ss-q-short" id="entry_523378717" dir="auto" aria-label="Họ và tên  " aria-required="true" required="" title="" placeholder="Họ và tên">
<div class="error-message" id="483055297_errorMessage"></div>
</div></div></div> <div class="ss-form-question errorbox-good" role="listitem">
<div dir="auto" class="ss-item ss-item-required ss-text"><div class="ss-form-entry">
<label class="ss-q-item-label" for="entry_476264857"><div class="ss-q-title"><!-- Enter your Email -->
<label for="itemView.getDomIdToLabel()" aria-label="(Required field)"></label>
<span class="ss-required-asterisk" aria-hidden="true"></span></div>
<div class="ss-q-help ss-secondary-text" dir="auto"></div></label>
<input type="email" name="entry.476264857" value="" class="ss-q-short" id="entry_476264857" dir="auto" aria-label="Enter your Email  " aria-required="true" required="" title="" placeholder="Email">
<div class="error-message" id="536771465_errorMessage"></div>
</div></div></div> <div class="ss-form-question errorbox-good" role="listitem">
<div dir="auto" class="ss-item ss-item-required ss-text"><div class="ss-form-entry">
<label class="ss-q-item-label" for="entry_544582500"><div class="ss-q-title"><!-- Điện thoại -->
<label for="itemView.getDomIdToLabel()" aria-label="(Required field)"></label>
<span class="ss-required-asterisk" aria-hidden="true"></span></div>
<div class="ss-q-help ss-secondary-text" dir="auto"></div></label>

<input type="number" name="entry.544582500" value="" class="ss-q-short" id="entry_544582500" dir="auto" aria-label="Điện thoại  Must be a number" aria-required="true" required="" step="any" title="Must be a number" placeholder="Điện thoại">

</div></div></div> <div class="ss-form-question errorbox-good" role="listitem">
<div dir="auto" class="ss-item ss-item-required ss-select"><div class="ss-form-entry">
<label class="ss-q-item-label" for="entry_688369767"><div class="ss-q-title"> <!-- Chi nhánh -->
<label for="itemView.getDomIdToLabel()" aria-label="(Required field)"></label>
<span class="ss-required-asterisk" aria-hidden="true"></span></div>
<div class="ss-q-help ss-secondary-text" dir="auto"></div></label>

<select name="entry.688369767" id="entry_688369767" aria-label=" Chi nhánh  " aria-required="true" required=""><option value="" disabled selected >Chọn chi nhánh gần nhất</option>
<option value="Ocean Edu Nguy&#7877;n L&#432;&#417;ng B&#7857;ng">Ocean Edu Nguyễn Lương Bằng</option> <option value="Ocean Edu Nam Dinh">Ocean Edu Nam Dinh</option> <option value="Ocean Edu Nguy&#7877;n Tr&atilde;i">Ocean Edu Nguyễn Trãi</option> <option value="Ocean Edu Royal City">Ocean Edu Royal City</option> <option value="Ocean Edu Times City">Ocean Edu Times City</option> <option value="Ocean Edu H&agrave; &#272;&ocirc;ng">Ocean Edu Hà Đông</option> <option value="Ocean Edu Xu&acirc;n Mai">Ocean Edu Xuân Mai</option> <option value="Ocean Edu Ph&#7911; L&yacute;">Ocean Edu Phủ Lý</option> <option value="Ocean Edu B&#7855;c Ninh">Ocean Edu Bắc Ninh</option> <option value="Ocean Edu T&#7915; S&#417;n">Ocean Edu Từ Sơn</option> <option value="Ocean Edu B&#7855;c Giang">Ocean Edu Bắc Giang</option> <option value="Ocean Edu Ph&uacute;c Y&ecirc;n">Ocean Edu Phúc Yên</option> <option value="Ocean Edu V&#297;nh Y&ecirc;n">Ocean Edu Vĩnh Yên</option> <option value="Ocean Edu H&#432;ng Y&ecirc;n">Ocean Edu Hưng Yên</option> <option value="Ocean Edu Ha&#777;i D&#432;&#417;ng 1">Ocean Edu Hải Dương 1</option> <option value="Ocean Edu Ha&#777;i D&#432;&#417;ng 2">Ocean Edu Hải Dương 2</option> <option value="Ocean Edu Vi&ecirc;&#803;t Tri&#768;">Ocean Edu Việt Trì</option> <option value="Ocean Edu Y&ecirc;n Ba&#769;">Ocean Edu Yên Bá</option> <option value="Ocean Edu La&#768;o Cai">Ocean Edu Lào Cai</option> <option value="Ocean Edu Tha&#769;i Nguy&ecirc;n">Ocean Edu Thái Nguyên</option> <option value="Ocean Edu Tha&#769;i Bi&#768;nh">Ocean Edu Thái Bình</option> <option value="Ocean Edu Ninh Bi&#768;nh">Ocean Edu Ninh Bình</option> <option value="Ocean Edu Thanh H&oacute;a">Ocean Edu Thanh Hóa</option> <option value="Ocean Edu Vinh">Ocean Edu Vinh</option> <option value="Ocean Edu Bu&ocirc;n Ma Thu&#7897;t">Ocean Edu Buôn Ma Thuột</option> <option value="Ocean Edu H&ograve;a B&igrave;nh">Ocean Edu Hòa Bình</option> <option value="Ocean Edu Tam &#272;i&#7879;p">Ocean Edu Tam Điệp</option> <option value="Ocean Edu Minh Khai">Ocean Edu Minh Khai</option> <option value="Ocean Edu Linh &#272;&agrave;m">Ocean Edu Linh Đàm</option> <option value="Ocean Edu Ph&#7841;m V&#259;n &#272;&#7891;ng">Ocean Edu Phạm Văn Đồng</option> <option value="Ocean Edu Kim V&#259;n Kim L&#361;">Ocean Edu Kim Văn Kim Lũ</option> <option value="Ocean Edu Tr&#432;&#417;ng &#272;&#7883;nh">Ocean Edu Trương Định</option> <option value="Ocean Edu Tuy Hoa Phu Yen">Ocean Edu Tuy Hoa Phu Yen</option> <option value="Ocean Edu H&agrave; T&#297;nh">Ocean Edu Hà Tĩnh</option> <option value="Ocean Edu H&#7841; Long">Ocean Edu Hạ Long</option> <option value="Ocean Edu C&#7849;m Ph&#7843;">Ocean Edu Cẩm Phả</option> <option value="Ocean Edu L&#7841;ng S&#417;n">Ocean Edu Lạng Sơn</option> <option value="Ocean Edu Ph&#7889; N&#7889;i">Ocean Edu Phố Nối</option></select>
</div></div></div>
<input type="hidden" name="draftResponse" value="[null,null,&quot;-3662415085834683696&quot;]
">
<input type="hidden" name="pageHistory" value="0">



<input type="hidden" name="fbzx" value="-3662415085834683696">
<div class="ss-send-email-receipt" style="margin-bottom: 4px;" dir="ltr"><label for="emailReceipt" style="display:inline;"></label></div>
<div class="ss-item ss-navigate"><table id="navigation-table"><tbody><tr><td class="ss-form-entry goog-inline-block" id="navigation-buttons" dir="ltr">
<input type="submit" name="submit" value="ĐĂNG KÝ" id="ss-submit" class="jfk-button jfk-button-action ">
</td>
</tr></tbody></table></div></ol></form></div>