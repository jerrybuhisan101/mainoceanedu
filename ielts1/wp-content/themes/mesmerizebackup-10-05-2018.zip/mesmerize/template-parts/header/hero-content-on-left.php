<div class="row header-description-row">
    <div class="header-content header-content-left col-sm-12 col-xs-12">
        <div class="<?php mesmerize_print_header_content_holder_class(); ?>">
            <?php mesmerize_print_header_content(); ?>
        </div>
    </div>
</div>
