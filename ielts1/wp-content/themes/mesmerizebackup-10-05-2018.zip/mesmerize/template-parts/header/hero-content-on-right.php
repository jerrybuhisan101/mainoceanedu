<div class="row header-description-row">
    <div class="header-content header-content-right col-sm-12 col-xs-12">
        <!-- <div class="<?php mesmerize_print_header_content_holder_class(); ?>">
        	<b>IELTS</b>
            <?php mesmerize_print_header_content(); ?>
        </div> -->

        <div class="align-holder right">
            <h1 class="hero-title"><b style="font-weight: 800;">OCEAN EDU </b><b style="color:#ee1c25;font-weight: 800;">IELTS</b></h1><p class="header-subtitle"><b>Bạn đã sẵn sàng chinh phục IELTS?</b></p><div data-dynamic-mod-container="" class="header-buttons-wrapper"><a class="button big color1 round" target="_self" href="#contact-1">Đăng ký kiểm tra trình độ đầu vào</a><a class="button big color-white round outline" target="_self" href="http://ielts.ocean.edu.vn/lien-he/">Đăng ký nhận tư vấn!</a></div>        </div>
    </div>
</div>


