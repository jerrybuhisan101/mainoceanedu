<div class="navigation-bar logo-above-menu <?php mesmerize_header_main_class() ?>" <?php mesmerize_navigation_sticky_attrs() ?>>
    <div class="navigation-wrapper <?php mesmerize_navigation_wrapper_class() ?>">
        <div class="row basis-auto between-xs">
	        <div class="logo_col col-xs col-sm-12 center-sm">
	            <?php mesmerize_print_logo(); ?>
	        </div>
	        <div class="main_menu_col col-xs-fit col-sm">
	            <?php mesmerize_print_primary_menu(); ?>
	        </div>
	    </div>
    </div>
</div>